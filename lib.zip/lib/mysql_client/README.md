# mysql_client
'mysql_client' is a MySQL client written in Erlang and provides API that is very close to Connector/C library. The client is using low level (TCP/IP socket) connection to MySQL server and allows to exchange a data with maximum possible speed. Multiple datasource support and connection pool are incapsulated in the client that increases a performance in concurrent environment.

For more information go to:
[http://erlmysql.sourceforge.net/](http://erlmysql.sourceforge.net/)