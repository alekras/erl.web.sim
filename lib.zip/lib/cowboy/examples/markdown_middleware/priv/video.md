HTML5 Video With Markdown
=========================

<video controls>
<source src="small.ogv" type="video/ogg"/>
<source src="small.mp4" type="video/mp4"/>
</video>

Videos taken from [TechSlides](http://techslides.com/sample-webm-ogg-and-mp4-video-files-for-html5/)
